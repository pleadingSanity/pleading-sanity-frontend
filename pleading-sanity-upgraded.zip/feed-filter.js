
function filterFeed(category) {
  fetch('content.json')
    .then(res => res.json())
    .then(data => {
      const feed = document.getElementById('scroll-feed');
      feed.innerHTML = '';
      let count = 0;
      data.videos.forEach((video, index) => {
        if (category === 'All' || video.category === category) {
          const card = document.createElement('div');
          card.className = 'video-card';
          card.innerHTML = `
            <video src="${video.src}" controls loop></video>
            <p>${video.caption}</p>
          `;
          feed.appendChild(card);
          count++;
          if (count % 15 === 0) {
            const ad = document.createElement('div');
            ad.className = 'quote-ad';
            ad.textContent = '“Survivors wear scars, not medals.”';
            feed.appendChild(ad);
          }
        }
      });
    });
}
filterFeed('All');
