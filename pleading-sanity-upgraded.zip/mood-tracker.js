
function saveMood(mood) {
  localStorage.setItem('lastMood', mood);
  document.getElementById('last-mood').textContent = "You last felt: " + mood;
}
window.onload = () => {
  const mood = localStorage.getItem('lastMood');
  if (mood) document.getElementById('last-mood').textContent = "You last felt: " + mood;
};
