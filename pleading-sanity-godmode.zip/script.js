const CONFIG = {
  hoodieBuy: "https://your-payhip-link",
  tracksuitUnlock: "https://your-unlock-link",
  joinForm: "https://formspree.io/f/yourid",
};

// Load feed dynamically
fetch("content.json")
  .then(r => r.json())
  .then(data => {
    const feed = document.getElementById("feed");
    data.feed.forEach(item => {
      const div = document.createElement("div");
      div.className = "feed-item";
      div.innerHTML = `<h3>${item.title}</h3><p>${item.text}</p>`;
      feed.appendChild(div);
    });
  });

// Merch links
document.getElementById("buyHoodie").href = CONFIG.hoodieBuy;
document.getElementById("unlockTracksuit").href = CONFIG.tracksuitUnlock;

// Join form
document.getElementById("joinForm").addEventListener("submit", e => {
  e.preventDefault();
  alert("Welcome to the movement. RISE FROM MADNESS.");
});
